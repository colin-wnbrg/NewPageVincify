
export interface Feature {
  title: string;
  description: string;
  imageUrl: string;
}
